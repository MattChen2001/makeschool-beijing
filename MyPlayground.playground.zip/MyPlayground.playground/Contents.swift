//: Playground - noun: a place where people can play

import UIKit

func judgeword(word:String)->Bool{
    let letters = word.characters
    var stringabcd = ""
    for i in letters{
        stringabcd.insert(i, at: letters.startIndex)
    }
    if  stringabcd == word{
        return true
    }
    else{
        return false
    }
}

judgeword(word: "abcba")


func judgeword2(word:String)->Bool{
    let letters = word.characters
    var stringabcd = ""
    for i in letters{
        stringabcd = String(i) + stringabcd
    }
    if  stringabcd == word{
        return true
    }
    else{
        return false
    }
}
judgeword2(word: "abcba")
judgeword2(word: "abc")
judgeword(word: "abc")
/////////////////////////////////////////////////////////////
/*I'm tryng to finish question2*/


func makeschool(array:[[Int]])->Bool{
    var result = true
    var newArray = [Int]()
    var numbers = 0
    var count = 0
    for i in array {
        newArray+=i
        count+=1
    }
    for _ in newArray{
        numbers+=1
    }
    for i in array{
        for o in 1...numbers/count-1  {
            if i[o-1]*2 != i[o] {
                result = false
                break
            }
        }
        
        for i in 1...numbers-numbers/count{
            if newArray[i-1]*2 != newArray[i-1+numbers/count]  {
                result = false
                break
            }
        }
    }

    return result
}
    
        
    



makeschool(array:   [[3,6,12],
                     [6,12,24],
                     [12,24,48]])

makeschool(array:   [[3,8,12],
                     [6,12,24],
                     ])

