//: Playground - noun: a place where people can play

import UIKit

func judgeword(word:String)->Bool{
    let letters = word.characters
    var stringabcd = ""
    for i in letters{
        stringabcd.insert(i, at: letters.startIndex)
    }
    if  stringabcd == word{
        return true
    }
    else{
        return false
    }
}

judgeword(word: "abcba")


func judgeword2(word:String)->Bool{
    let letters = word.characters
    var stringabcd = ""
    for i in letters{
        stringabcd = String(i) + stringabcd
    }
    if  stringabcd == word{
        return true
    }
    else{
        return false
    }
}
judgeword2(word: "abcba")
/////////////////////////////////////////////////////////////
/*I'm tryng to finish question2*/